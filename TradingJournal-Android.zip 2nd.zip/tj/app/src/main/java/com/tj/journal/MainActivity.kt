package com.tj.journal

import android.app.DatePickerDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.time.LocalDate
import java.time.YearMonth
import java.util.UUID

val Win = Color(0xFF117A57); val WinBg = Color(0xFFE4F5EE)
val Loss = Color(0xFFC23B3B); val LossBg = Color(0xFFFBE9E9)
val Blue = Color(0xFF2F5BEA); val BlueBg = Color(0xFFE6F0FF)
val Mute = Color(0xFF6B7690)
fun money(d: Double) = (if (d < 0) "-" else "") + "\$" + "%.2f".format(kotlin.math.abs(d))

/* ---------------- Data ---------------- */
data class Trade(
    val id: String, val date: String, val pair: String, val dir: String, val result: String,
    val lot: String, val sl: String, val tp: String, val strat: String,
    val before: Double, val after: Double,
    val reason: String, val mistake: String, val advice: String, val shots: List<String>
) { val pnl get() = after - before }

object Store {
    private fun file(c: Context, u: String) = File(c.filesDir, "trades_$u.json")
    fun load(c: Context, u: String): List<Trade> {
        val f = file(c, u)
        return if (f.exists()) try { parse(f.readText()) } catch (e: Exception) { emptyList() } else emptyList()
    }
    fun save(c: Context, u: String, l: List<Trade>) {
        val tmp = File(c.filesDir, "tmp_$u.json"); tmp.writeText(toJson(l)); tmp.renameTo(file(c, u))
    }
    fun parse(s: String): List<Trade> {
        val a = JSONArray(s)
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val sh = o.optJSONArray("shots")
            Trade(o.getString("id"), o.getString("date"), o.getString("pair"), o.optString("dir"), o.optString("result"),
                o.optString("lot"), o.optString("sl"), o.optString("tp"), o.optString("strat"),
                o.optDouble("before", 0.0), o.optDouble("after", 0.0),
                o.optString("reason"), o.optString("mistake"), o.optString("advice"),
                if (sh == null) emptyList() else (0 until sh.length()).map { sh.getString(it) })
        }
    }
    fun toJson(l: List<Trade>): String = JSONArray(l.map { t ->
        JSONObject().put("id", t.id).put("date", t.date).put("pair", t.pair).put("dir", t.dir).put("result", t.result)
            .put("lot", t.lot).put("sl", t.sl).put("tp", t.tp).put("strat", t.strat)
            .put("before", t.before).put("after", t.after).put("reason", t.reason)
            .put("mistake", t.mistake).put("advice", t.advice).put("shots", JSONArray(t.shots))
    }).toString()
}

/* ---------------- Login system (on this phone) ---------------- */
object Auth {
    private fun p(c: Context) = c.getSharedPreferences("auth", 0)
    private fun hash(salt: String, pw: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + pw).toByteArray()).joinToString("") { "%02x".format(it) }
    fun hasAny(c: Context) = p(c).all.keys.any { it.startsWith("u_") }
    fun register(c: Context, u: String, pw: String): String? {
        val n = u.trim().lowercase()
        if (n.length < 3) return "Username must be at least 3 characters"
        if (pw.length < 4) return "Password must be at least 4 characters"
        if (p(c).contains("u_$n")) return "This username already exists"
        val salt = UUID.randomUUID().toString()
        p(c).edit().putString("u_$n", "$salt:${hash(salt, pw)}").putString("cur", n).apply()
        return null
    }
    fun login(c: Context, u: String, pw: String): String? {
        val n = u.trim().lowercase()
        val s = p(c).getString("u_$n", null) ?: return "No account found with this username"
        val (salt, h) = s.split(":")
        if (hash(salt, pw) != h) return "Wrong password"
        p(c).edit().putString("cur", n).apply(); return null
    }
    fun current(c: Context) = p(c).getString("cur", null)
    fun logout(c: Context) = p(c).edit().remove("cur").apply()
}

fun saveShot(c: Context, uri: Uri): String? {
    try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1; while (o.outWidth / s > 1400) s *= 2
        val bmp = c.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        } ?: return null
        val f = File(File(c.filesDir, "shots").apply { mkdirs() }, UUID.randomUUID().toString() + ".jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 75, it) }
        return f.absolutePath
    } catch (e: Exception) { return null }
}

/* ---------------- UI ---------------- */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue)) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFFF4F6FA)) { App() }
            }
        }
    }
}

@Composable fun App() {
    val c = LocalContext.current
    var user by remember { mutableStateOf(Auth.current(c)) }
    val u = user
    if (u == null) AuthScreen { user = it } else Home(u) { Auth.logout(c); user = null }
}

@Composable fun AuthScreen(onDone: (String) -> Unit) {
    val c = LocalContext.current
    var reg by remember { mutableStateOf(!Auth.hasAny(c)) }
    var u by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center) {
        Text("Trading Journal", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(if (reg) "Create your account" else "Log in to continue", color = Mute)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(u, { u = it }, Modifier.fillMaxWidth(), label = { Text("Username") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(p, { p = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation())
        err?.let { Text(it, color = Loss, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(14.dp))
        Button({
            val e = if (reg) Auth.register(c, u, p) else Auth.login(c, u, p)
            if (e == null) onDone(Auth.current(c)!!) else err = e
        }, Modifier.fillMaxWidth()) { Text(if (reg) "Create account" else "Log in") }
        TextButton({ reg = !reg; err = null }) { Text(if (reg) "I already have an account" else "Create new account") }
    }
}

@Composable fun Home(user: String, onLogout: () -> Unit) {
    val c = LocalContext.current
    var trades by remember { mutableStateOf(Store.load(c, user)) }
    fun commit(l: List<Trade>) { trades = l; Store.save(c, user, l) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var sel by remember { mutableStateOf(LocalDate.now().toString()) }
    var form by remember { mutableStateOf<Trade?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let {
            c.contentResolver.openOutputStream(it)?.use { o -> o.write(Store.toJson(trades).toByteArray()) }
            Toast.makeText(c, "Backup saved", Toast.LENGTH_SHORT).show()
        }
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            try {
                val l = Store.parse(c.contentResolver.openInputStream(it)!!.bufferedReader().readText())
                commit(trades.filter { t -> l.none { x -> x.id == t.id } } + l)
                Toast.makeText(c, "Restored ${l.size} trades", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(c, "Invalid backup file", Toast.LENGTH_SHORT).show() }
        }
    }

    val mt = trades.filter { it.date.startsWith(month.toString()) }
    val total = mt.sumOf { it.pnl }
    val wins = mt.count { it.pnl > 0 }
    val byDay = trades.groupBy { it.date }.mapValues { e -> e.value.sumOf { t -> t.pnl } }
    val day = trades.filter { it.date == sel }
    val cnt = trades.groupingBy { it.date }.eachCount()
    val lastBal = (day.lastOrNull() ?: trades.filter { it.date < sel }.maxByOrNull { it.date })
        ?.after?.let { "%.2f".format(it) } ?: ""

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Trading Journal", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Signed in as $user", color = Mute, fontSize = 12.sp)
            }
            Box {
                TextButton({ menu = true }) { Text("Menu") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Backup data") }, { menu = false; exp.launch("trading-journal-backup.json") })
                    DropdownMenuItem({ Text("Restore backup") }, { menu = false; imp.launch(arrayOf("*/*")) })
                    DropdownMenuItem({ Text("Log out") }, { menu = false; onLogout() })
                }
            }
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Stat("Monthly P&L", money(total), if (total >= 0) Win else Loss, Modifier.weight(1f))
                Stat("Trades", "${mt.size}", Color.Black, Modifier.weight(1f))
                Stat("Win rate", "${if (mt.isEmpty()) 0 else wins * 100 / mt.size}%", Color.Black, Modifier.weight(1f))
            }
            Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton({ month = month.minusMonths(1) }) { Text("‹", fontSize = 20.sp) }
                        Text("${month.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${month.year}",
                            Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                        TextButton({ month = month.plusMonths(1) }) { Text("›", fontSize = 20.sp) }
                    }
                    Row { "S M T W T F S".split(" ").forEach {
                        Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, color = Mute, fontSize = 12.sp) } }
                    val first = month.atDay(1).dayOfWeek.value % 7
                    val cells = List(first) { null } + (1..month.lengthOfMonth()).map { month.atDay(it).toString() }
                    cells.chunked(7).forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            for (i in 0 until 7) {
                                val d = row.getOrNull(i)
                                Cell(d, d?.let { byDay[it] }, d?.let { cnt[it] } ?: 0, d == sel, Modifier.weight(1f)) { if (d != null) sel = d }
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(sel, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Button({ form = null; showForm = true }) { Text("+ Add trade #${day.size + 1}") }
            }
            if (day.isEmpty()) Text("No trades on this day. Tap “Add trade” to log one.", color = Mute)
            else {
                val dp = day.sumOf { it.pnl }
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat("Trades today", "${day.size}", Color.Black, Modifier.weight(1f))
                    Stat("Wins / Losses", "${day.count { it.pnl > 0 }} / ${day.count { it.pnl < 0 }}", Color.Black, Modifier.weight(1f))
                    Stat("Day P&L", money(dp), if (dp >= 0) Win else Loss, Modifier.weight(1f))
                }
            }
            day.forEachIndexed { i, t ->
                TradeCard(t, i + 1, { form = t; showForm = true }) {
                    t.shots.forEach { File(it).delete() }; commit(trades.filter { x -> x.id != t.id })
                }
            }
        }
    }
    if (showForm) TradeForm(form, sel, lastBal, (form?.let { f -> day.indexOfFirst { it.id == f.id } + 1 } ?: (day.size + 1)), { showForm = false }) { t ->
        commit(if (trades.any { it.id == t.id }) trades.map { x -> if (x.id == t.id) t else x } else trades + t)
        sel = t.date; month = YearMonth.from(LocalDate.parse(t.date)); showForm = false
    }
}

@Composable fun Stat(l: String, v: String, col: Color, mod: Modifier) {
    Card(mod, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp)) {
            Text(l, color = Mute, fontSize = 11.sp); Text(v, color = col, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable fun Cell(d: String?, p: Double?, n: Int, sel: Boolean, mod: Modifier, click: () -> Unit) {
    if (d == null) { Spacer(mod.height(52.dp)); return }
    val bg = when { p == null -> Color.Transparent; p > 0 -> WinBg; p < 0 -> LossBg; else -> Color(0xFFEEEEEE) }
    val shape = RoundedCornerShape(8.dp)
    Box(mod.padding(2.dp).height(48.dp).background(bg, shape)
        .border(if (sel) 2.dp else 1.dp, if (sel) Blue else Color(0xFFE3E8F0), shape)
        .clickable { click() }.padding(4.dp)) {
        Text(d.takeLast(2).trimStart('0'), fontSize = 11.sp, color = Mute)
        if (n > 0) Text("×$n", Modifier.align(Alignment.TopEnd), fontSize = 10.sp, color = Blue, fontWeight = FontWeight.Bold)
        if (p != null) Text("%+.0f".format(p), Modifier.align(Alignment.BottomEnd), fontSize = 11.sp,
            fontWeight = FontWeight.Bold, color = if (p >= 0) Win else Loss)
    }
}

@Composable fun Hl(title: String, fg: Color, bg: Color, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    Column(Modifier.fillMaxWidth().background(bg, shape).border(1.dp, fg.copy(alpha = .5f), shape).padding(10.dp)) {
        Text(title, color = fg, fontWeight = FontWeight.Bold, fontSize = 13.sp); content()
    }
}

@Composable fun Shot(path: String, mod: Modifier, fit: Boolean = false) {
    val bmp = remember(path) { BitmapFactory.decodeFile(path)?.asImageBitmap() }
    if (bmp != null) Image(bmp, null, mod, contentScale = if (fit) ContentScale.Fit else ContentScale.Crop)
}

@Composable fun TradeCard(t: Trade, no: Int, onEdit: () -> Unit, onDelete: () -> Unit) {
    var zoom by remember { mutableStateOf<String?>(null) }
    var ask by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Trade #$no", color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(t.pair, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("${t.dir} • ${t.result}", color = Mute, fontSize = 12.sp)
                }
                Text(money(t.pnl), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = if (t.pnl >= 0) Win else Loss)
            }
            Text("Lot ${t.lot.ifBlank { "-" }}   SL ${t.sl.ifBlank { "-" }}   TP ${t.tp.ifBlank { "-" }}", color = Mute, fontSize = 13.sp)
            Text("Balance ${money(t.before)} → ${money(t.after)}", color = Mute, fontSize = 13.sp)
            if (t.strat.isNotBlank()) Text("Strategy: ${t.strat}", fontSize = 14.sp)
            if (t.reason.isNotBlank()) Text("Reason: ${t.reason}", fontSize = 14.sp)
            Hl("Mistake", Loss, LossBg) { Text(t.mistake.ifBlank { "Nothing noted" }, fontSize = 14.sp) }
            Hl("Advice", Blue, BlueBg) { Text(t.advice.ifBlank { "Nothing noted" }, fontSize = 14.sp) }
            if (t.shots.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                t.shots.forEach { p -> Shot(p, Modifier.size(90.dp).clickable { zoom = p }) }
            }
            Row { TextButton(onEdit) { Text("Edit") }; TextButton({ ask = true }) { Text("Delete", color = Loss) } }
        }
    }
    zoom?.let { z -> Dialog({ zoom = null }) { Shot(z, Modifier.fillMaxWidth(), fit = true) } }
    if (ask) AlertDialog(onDismissRequest = { ask = false },
        title = { Text("Delete this trade?") },
        confirmButton = { TextButton({ ask = false; onDelete() }) { Text("Delete", color = Loss) } },
        dismissButton = { TextButton({ ask = false }) { Text("Cancel") } })
}

@Composable fun F(label: String, v: String, mod: Modifier = Modifier.fillMaxWidth(), lines: Int = 1,
                  num: Boolean = false, on: (String) -> Unit) {
    OutlinedTextField(v, on, mod, label = { Text(label) }, minLines = lines, singleLine = lines == 1,
        keyboardOptions = if (num) KeyboardOptions(keyboardType = KeyboardType.Decimal) else KeyboardOptions.Default)
}

@Composable fun Chips(o: List<String>, s: String, on: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { o.forEach { FilterChip(s == it, { on(it) }, { Text(it) }) } }
}

@Composable fun TradeForm(t: Trade?, day: String, lastBal: String, num: Int, onClose: () -> Unit, onSave: (Trade) -> Unit) {
    val c = LocalContext.current
    var date by remember { mutableStateOf(t?.date ?: day) }
    var pair by remember { mutableStateOf(t?.pair ?: "") }
    var dir by remember { mutableStateOf(t?.dir ?: "Buy") }
    var res by remember { mutableStateOf(t?.result ?: "Win") }
    var lot by remember { mutableStateOf(t?.lot ?: "") }
    var strat by remember { mutableStateOf(t?.strat ?: "") }
    var sl by remember { mutableStateOf(t?.sl ?: "") }
    var tp by remember { mutableStateOf(t?.tp ?: "") }
    var before by remember { mutableStateOf(t?.before?.let { "%.2f".format(it) } ?: lastBal) }
    var after by remember { mutableStateOf(t?.after?.let { "%.2f".format(it) } ?: "") }
    var reason by remember { mutableStateOf(t?.reason ?: "") }
    var mistake by remember { mutableStateOf(t?.mistake ?: "") }
    var advice by remember { mutableStateOf(t?.advice ?: "") }
    var shots by remember { mutableStateOf(t?.shots ?: emptyList()) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { us ->
        us.take(4 - shots.size).forEach { u -> saveShot(c, u)?.let { shots = shots + it } }
    }
    val pnl = (after.toDoubleOrNull() ?: 0.0) - (before.toDoubleOrNull() ?: 0.0)
    val half = Modifier.fillMaxWidth()

    Dialog(onClose, DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF4F6FA)) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (t == null) "New trade #$num" else "Edit trade #$num", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OutlinedButton({
                    val d = LocalDate.parse(date)
                    DatePickerDialog(c, { _, y, m, dd -> date = LocalDate.of(y, m + 1, dd).toString() },
                        d.year, d.monthValue - 1, d.dayOfMonth).show()
                }, half) { Text("Date: $date") }
                F("Currency pair (e.g. EUR/USD)", pair) { pair = it }
                Chips(listOf("Buy", "Sell"), dir) { dir = it }
                Chips(listOf("Win", "Loss", "Breakeven"), res) { res = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    F("Lot size", lot, Modifier.weight(1f), num = true) { lot = it }
                    F("Strategy", strat, Modifier.weight(1f)) { strat = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    F("Risk (SL)", sl, Modifier.weight(1f)) { sl = it }
                    F("Reward (TP)", tp, Modifier.weight(1f)) { tp = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    F("Balance before", before, Modifier.weight(1f), num = true) { before = it }
                    F("Balance after", after, Modifier.weight(1f), num = true) { after = it }
                }
                Text("P&L: ${money(pnl)}", color = if (pnl >= 0) Win else Loss, fontWeight = FontWeight.Bold)
                F("Reason for trade", reason, lines = 3) { reason = it }
                Hl("Mistake (important)", Loss, LossBg) { F("What went wrong?", mistake, lines = 3) { mistake = it } }
                Hl("Advice (important)", Blue, BlueBg) { F("What will I do next time?", advice, lines = 3) { advice = it } }
                Text("Chart screenshots (max 4)", color = Mute)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    shots.forEach { p ->
                        Box {
                            Shot(p, Modifier.size(90.dp))
                            Text("×", Modifier.align(Alignment.TopEnd).background(Color.White).clickable { shots = shots - p }.padding(6.dp))
                        }
                    }
                    if (shots.size < 4) OutlinedButton({ pick.launch("image/*") }) { Text("+ Add") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClose, Modifier.weight(1f)) { Text("Cancel") }
                    Button({
                        if (pair.isBlank()) Toast.makeText(c, "Enter the currency pair", Toast.LENGTH_SHORT).show()
                        else onSave(Trade(t?.id ?: UUID.randomUUID().toString(), date, pair.trim().uppercase(), dir, res,
                            lot, sl, tp, strat, before.toDoubleOrNull() ?: 0.0, after.toDoubleOrNull() ?: 0.0,
                            reason, mistake, advice, shots))
                    }, Modifier.weight(1f)) { Text("Save trade") }
                }
            }
        }
    }
}
